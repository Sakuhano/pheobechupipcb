G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-07-02T15:34:58+02:00*
G04 #@! TF.ProjectId,pheobechupi,7068656f-6265-4636-9875-70692e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-07-02 15:34:58*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.900000*%
%ADD11C,7.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X110250000Y-36500000D03*
D11*
X110250000Y-36500000D03*
G04 #@! TD*
M02*
